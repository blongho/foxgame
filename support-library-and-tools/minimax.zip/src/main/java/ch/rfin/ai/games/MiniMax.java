package ch.rfin.ai.games;

import ch.rfin.ai.games.AdversarialSearchAlgorithm;

/**
 * An implementation of the MiniMax algorithm with pruning, also known as
 * Alpha-Beta-Search.
 * Note that, for this exercise, you should ignore the evaluation function.
 * (The tests assume that your algorithm uses the utilities at the leaves.)
 * One way to accomplish this is to simply set the cutoff such that the
 * evaluation function becomes irrelevant. That way you don't have to create
 * two versions of the same algorithm - a "real" and a nerfed one. You
 * just have to use a suitable parameter to control the behavior.
 *
 * @author Christoffer Fink
 */
public class MiniMax<S,A> implements AdversarialSearchAlgorithm<S,A> {

  @Override
  public A bestMove(Game<S,A> game, EvalFunction<S> eval, S state) {
    throw new UnsupportedOperationException("Not implemented."); // your code here ...
  }

  // ... and here

}
