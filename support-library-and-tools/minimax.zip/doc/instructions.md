### Minimax Exercise

In this exercise you will implement the Minimax algorithm with pruning.
Although you are not required to, you will probably want to use this algorithm
in your FoxGame agent. So this is a good opportunity to get it right first,
before incorporating it into your agent, should you choose to use it.

As usual, the comments in the code provide more details.

minimax.zip contains two classes (in the src dir):

- `MiniMax`
- `Test`

`MiniMax` is the class you will modify. It only has a `bestMove` method, which
takes a `Game`, an `EvalFunction`, and a state. It should return the best
action available in the given state.

Inside the zip there is also a `lib/game.jar` containing:

- `Game`
- `AdversarialSearchAlgorithm`
- `EvalFunction`
- etc
- some utilities (see blow)

`Game` defines the rules of the game. It allows you to check whether a state
is a terminal state, what the utility of a state is, get all the possible
actions for a state, and it generates the successor state given a start state
and an action. You can also ask it who the current player (MIN or MAX) is in a
given state.

(`game.jar` includes the source code if you're interested.
You may also want to consider building the javadoc for these.)

**Your task is to implement MiniMax with alpha-beta pruning by completing the
`bestMove` method.**

You can run the `Test` class to test your algorithm. It will make sure you
produce the correct solution, and it will look at how your algorithm
traverses the tree and evaluates states. This means that you have to go
through the successors in the order in which they are returned by
`Game.possibleActionsIn(state)`, which shouldn't be a problem, since that's
also the easiest to implement - it's what a for-loop would normally do. It just
means that you would go through the tree left-to-right if you were to draw it.

`game.jar` also contains some extra tools for experimentation:

`InstrumentedGame` allows you to examine the behavior of your algorithm.
It wraps a game and keeps track of the calls your algorithm makes to it. It can
even track pruning (which states/actions were unexplored or unexamined).

`GameBuilder` allows you to easily build simple games by specifying which
successors a state has and what utility value a leaf state has. See the
documentation for more info.

This time I've removed the dependency on JUnit. So you just run `Test` as
a normal Java application.

Create any helper classes you deem appropriate.
